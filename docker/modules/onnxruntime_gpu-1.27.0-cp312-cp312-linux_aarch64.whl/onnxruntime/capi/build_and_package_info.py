package_name = 'onnxruntime-gpu'
__version__ = '1.27.0'
